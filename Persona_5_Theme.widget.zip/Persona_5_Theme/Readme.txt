Hi! This is my first time doing a Theme and sharing it so please let me know if there are any issues or if you have any suggestions.

Widget are fairly easy to use.
*IMPORTANT make sure that all the widgets(jsx files), assets and scripts are in a folder named Persona_5_Theme.

Just move the folder to the ubersicht widget folder. *Remember to send the background widget to background or else it will cover everything in the screen.

Before using the Calendar widget please modify the the following values of Calendar.jsx in any text editor.

key = please obtain a key from openweather order to use the weather
the_location = location sent to openweather to retrieve weather data
theme = normal or inverted.

if you want to change the position of the calendar widget or cpu-ram widget please modify:
top
right  
left 
value under className. 
*Do not change the top,right or left from any other css class unless you know what you are doing and want to change or adjust the display of any individual widget.

for issues or suggestion please feel free to email at juanjosepazroman@hotmail.com

